package tese1;

public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		App app=new App();
		app.Print_List();
	}

}
