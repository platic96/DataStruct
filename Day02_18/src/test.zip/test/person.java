package test;

public class person {
	int ok =0;
	int no =0;
	
}
