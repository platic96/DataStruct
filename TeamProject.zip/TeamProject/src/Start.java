
public class Start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		SRT srt = new SRT(5,11);
		Manager man = new Manager();
		User us = new User("0",500);
		man.Book_Seat(0, us);
		man.cancle_Seat(0, us);
		/*System.out.println(srt.IsSoldout());
		srt.Choice_Seat(1, us);
		srt.PrintAll();
		srt.Cancle_Seat(us);
		*/
	}

}
