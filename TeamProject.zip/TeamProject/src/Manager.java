
public class Manager {
	private MyDList userList = new MyDList();
	private SRT srt;
	private MyQueue queue;

	public Manager() {
		srt = new SRT(5,5);
		queue = new MyQueue(10);
	}

	// ���ο� ȸ���� �߰��ϴ� �޼���
	public boolean InsertUser(String userId, int balance) {

		if (userId.equals("") || SelectUser(userId) != null) {
			return false;
		}

		User newUser = new User(userId,  balance);
		if (!userList.push_back(newUser)) 
			return false;

		return true;		
	}

	// ȸ�� ������ ��ȸ�ϴ� �޼���
	public User SelectUser(String userId) {
		MyDList.DNode node = userList.select(userId);

		if (node != null) return (User) node.getData() ;
		else return null;
	}

	// ��� ȸ�� ������ ��ȸ�ϴ� �޼���
	public void PrintAllUser() {
		System.out.println("-----------------------------------------------------------------------------------------");
		System.out.println("���� ȸ�� ���� "+userList.getSize()+"���Դϴ�.");
		if (userList.getHead()  != null)
			userList.selectNextAll();
		System.out.println("-----------------------------------------------------------------------------------------");
	}


	// ȸ���� �����ϴ� �޼���
	public boolean DeleteUser(String userId) {

		MyDList.DNode del = userList.select(userId);
		if ( del != null) {
			userList.erase_random(del);
			return true;
		}
		else {
			return false;
		}
	}

	//�¼� ����
	public boolean Book_Seat(int Seat_number,User userId) {
		return srt.Choice_Seat(Seat_number, userId);
	}
	
	public boolean cancle_Seat(int Seat_number,User userId) {
		return srt.Cancle_Seat(userId);
	}
	
	public boolean waitUserAdd(User user) {
		return queue.Put(user);
	}
	
	public boolean waitUserDel() {
		if(queue.get()==null)
			return false;
		else
			return true;
	}

}
