
public class MyDList {
	
	// inner class ------------------------------------------------------------------------------------
	public class DNode { // DNode�� MyDList������ ���Ǵ� ���� Ŭ����
		Object data; // ����� ������
		DNode prev; // ���� ���
		DNode next; // ���� ���
		
		public DNode(Object data) {
			this.data= data;
			this.prev = null;
			this.next = null;
		}
		
		public Object getData() {
			return data;
		}
	} // end inner class
	
	// member field ------------------------------------------------------------------------------------
	private DNode head; // 
	private DNode tail;
	private int size;
	
	// Constructor ------------------------------------------------------------------------------------
	public MyDList() {
		this.head = null;
		this.tail = null;
		this.size = 0;
	}

	// insert method ------------------------------------------------------------------------------------
	public boolean push_front(Object data) { 
		DNode newnode = new DNode(data);  // ��� ���� �� �ʱ�ȭ
		
		if ( this.head == null ) { // DList�� ��� �ִ� ��Ȳ : head == null && tail == null
			this.head = newnode;
			this.tail = newnode;
		}
		else { // ���� Node�� �ִ� ��Ȳ
			newnode.next = this.head;
			head.prev = newnode;
			this.head = newnode;
		}
		size ++;
		return true;
	}
	public boolean push_back(Object data) {
		DNode newnode = new DNode(data);
		
		if (head == null ) { // ���� ��尡 �ϳ��� ���� ���
			head = newnode;
			tail = newnode;
		}
		else {
			newnode.prev = tail;
			tail.next = newnode;
			tail = newnode;
		}
		size ++;
		return true;
	}
	public boolean push_random(DNode cur, Object data) { // cur ������ ����
		
		if (cur.next == null) { // ������ ��� ���� ����
			return push_back(data);
		}

		// ���� ��� �߰��� �����ϴ� ��Ȳ
		DNode newnode = new DNode(data);

		newnode.prev = cur;
		newnode.next = cur.next;
		cur.next.prev = newnode;
		cur.next = newnode;
		
		size++;		
		return true;
	}
	
	// search method ------------------------------------------------------------------------------------
	public DNode select(Object key) { // �˻�(�˻� ������ ---> DNode ��ȯ(����:null)) 
		DNode cur = head;
		while(cur != null) {
			Object data = cur.data;
			
			if (data instanceof User) {
				User user = (User)data;
				if ( user.getUserId().equals(key)) {
					return cur;
				}
			}
			else {
				if ( data.equals(key)) {
					return cur;
				}
			}
			cur = cur.next;
		}
		return null;
	}

	// traverse  method ------------------------------------------------------------------------------------
	public void selectNextAll() { // head -> tail 
		
		DNode cur = head;
		while(cur != null) {
			Object data = cur.data ;	
			System.out.println(data.toString());
			cur = cur.next;
		}
	}
	
	// delete method ------------------------------------------------------------------------------------
	public boolean erase_front() { // ������ ��带 ����Ų��.
		
		if (head == null ) return false;
		else 	if ( head.next == null) {  // head.next == null �Ǵ� tail.prev = null
			head = tail = null;
		} 
		else  {
			DNode del = head;
			head = del.next;
			head.prev = null;
		}
		size --;
		return true;
	}

	public boolean erase_back() {
		if (head == null) return false;
		else if (head.next == null) {
			head = tail = null;
		}
		else {
			DNode delPrev = tail.prev;
			delPrev.next = null;
			tail = delPrev;
		}
		size --;
		return true;
	}
	public boolean erase_random(DNode del) { // �ش� ��带 ����
		if (del == null ) return false;
		
		if (del.prev == null) { // ��尡 1��
			return erase_front();
		}
		else if(del.next == null) { // ��尡 2��
			return erase_back();
		}
		else { // ��尡 3�� �̻�
			DNode prev = del.prev;
			prev.next = del.next;
			del.next.prev = prev;
// 		�Ʒ� �ڵ嵵 ������ �۵�
//			del.prev.next = del.next;
//			del.next.prev = del.prev;
			size--;
			return true;	
		}
	}
	
	// �ʱ�ȭ
	public void clear() {
		head = tail = null;
		size = 0;
	}

	// Getter ---------------------------------------------------------------------------------------------------
	public DNode getHead() {
		return head;
	}
	
	public int getSize() {
		return this.size;
		
	}
	

}
