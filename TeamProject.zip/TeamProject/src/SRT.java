
public class SRT {
	public class Seat{
		private String userId;
		
		public Seat()
		{
			this.userId = null;
		}
		
		public boolean IsEmpty() {
			return userId==null;
		}
		
		public boolean Reservation(String userId) {
			if(IsEmpty()==true) {
				this.userId = userId;
				return true;
			}
			else
				return false;
		}
		
		public void Cancle() {
			this.userId = " ";
		}
	}
	
	private Seat[] seatArr;
	private int SRT_Number;
	private int seatCount;
	private int Charge;
	
	//������
//	public SRT(int seatCount,int SRT_Number) {
//		this(seatCount,SRT_Number,40);
//	}
//	
	public SRT(int seatCount,int SRT_Number) {
		this.seatArr= new Seat[seatCount];
		this.SRT_Number = SRT_Number;
		this.seatCount = 0;
		this.Charge = 400;
		for(int i=0;i<seatCount;i++)
			seatArr[i]=new Seat();
	}
	
	//�޼ҵ�
	//��ü ���
	public void PrintAll() {
		for(int i=0;i<seatArr.length;i++) {
			if(seatArr[i].IsEmpty()==false)
				System.out.print("1 ");
			else
				System.out.print("0 ");
		}
		System.out.println(" ");
	}
	
	//����Ȯ��
	public boolean IsSoldout() {
		return (seatArr.length <= seatCount);
	}
	
	//�¼� ����
	public boolean Choice_Seat(int Seat_number,User userId) {
		PrintAll();
		if(IsSoldout()==true)
		{
				System.out.println("�¼��� ���� á���ϴ�.");
				return false;
		}
		else {
			if(seatArr[Seat_number].IsEmpty()==false) {
				System.out.println("�¼��� �̹� ����Ǿ����ϴ�.");
				return false;
			}
			else
			{
				if(userId.getBalance()<this.Charge)
					return false;
				else
				{
					System.out.println("���࿡ �����߽��ϴ�.");
					seatArr[Seat_number].Reservation(userId.getUserId());
					userId.Pay(Charge);
					seatCount++;
				}
				
				
			}
		}
		return true;
	}
	
	//�¼� ���
	public boolean Cancle_Seat(User userId) {
		for(int i=0;i<seatArr.length;i++) {
			if(seatArr[i].userId == userId.getUserId())
				{
					seatArr[i].Cancle();
					userId.Save(Charge);
					seatCount--;
					System.out.println("������ �����߽��ϴ�.");
					return true;
				}
		}
		System.out.println("�ش� ���̵�� ������� �ʾҽ��ϴ�.");
		return false;
	}
}
